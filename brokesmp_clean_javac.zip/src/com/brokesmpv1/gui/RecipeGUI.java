package com.brokesmpv1.gui;

import com.brokesmpv1.BrokeSMPV1;
import com.brokesmpv1.shards.ShardType;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/**
 * RecipeGUI - visual 3x3 recipe viewer.
 *
 * Usage: RecipeGUI.open(player);
 * If the player has a shard equipped, it shows that shard's 3x3 recipe.
 * If not, it opens a simple selector listing all shards (clicks on selector are not handled here).
 *
 * Grid slots inside a 27-slot inventory (centered):
 *   3  4  5
 *  12 13 14
 *  21 22 23
 *
 * Result slot: 16
 */
public class RecipeGUI {

    private static final int[] GRID_SLOTS = {3,4,5,12,13,14,21,22,23};
    private static final int RESULT_SLOT = 16;
    private static final ItemStack BG_PANE = makeGlassPane(" ");

    // Map each shard type to a 3x3 ingredient array (row-major). Use Material.AIR for empty.
    private static final Map<ShardType, Material[]> RECIPES = new EnumMap<>(ShardType.class);

    static {
        RECIPES.put(ShardType.INFERNO_BLADE, new Material[]{
                Material.BLAZE_POWDER, Material.REDSTONE, Material.BLAZE_POWDER,
                Material.REDSTONE, Material.ANVIL,       Material.REDSTONE,
                Material.BLAZE_POWDER, Material.REDSTONE, Material.BLAZE_POWDER
        });

        RECIPES.put(ShardType.VAMPIRE_DAGGER, new Material[]{
                Material.WITHER_SKELETON_SKULL, Material.REDSTONE, Material.WITHER_SKELETON_SKULL,
                Material.REDSTONE, Material.ENDER_PEARL, Material.REDSTONE,
                Material.WITHER_SKELETON_SKULL, Material.REDSTONE, Material.WITHER_SKELETON_SKULL
        });

        RECIPES.put(ShardType.STORMBREAKER_AXE, new Material[]{
                Material.HEART_OF_THE_SEA, Material.REDSTONE, Material.HEART_OF_THE_SEA,
                Material.REDSTONE, Material.ANVIL, Material.REDSTONE,
                Material.HEART_OF_THE_SEA, Material.REDSTONE, Material.HEART_OF_THE_SEA
        });

        RECIPES.put(ShardType.FROSTBRAND, new Material[]{
                Material.BLUE_ICE, Material.PRISMARINE_SHARD, Material.BLUE_ICE,
                Material.PRISMARINE_SHARD, Material.ANVIL, Material.PRISMARINE_SHARD,
                Material.BLUE_ICE, Material.PRISMARINE_SHARD, Material.BLUE_ICE
        });

        RECIPES.put(ShardType.WITHER_SCYTHE, new Material[]{
                Material.WITHER_SKELETON_SKULL, Material.ENDER_PEARL, Material.WITHER_SKELETON_SKULL,
                Material.ENDER_PEARL, Material.ANVIL, Material.ENDER_PEARL,
                Material.WITHER_SKELETON_SKULL, Material.ENDER_PEARL, Material.WITHER_SKELETON_SKULL
        });

        RECIPES.put(ShardType.SHADOW_KATANA, new Material[]{
                Material.ENDER_PEARL, Material.REDSTONE, Material.ENDER_PEARL,
                Material.REDSTONE, Material.ANVIL, Material.REDSTONE,
                Material.ENDER_PEARL, Material.REDSTONE, Material.ENDER_PEARL
        });

        RECIPES.put(ShardType.PHOENIX_BOW, new Material[]{
                Material.BOW, Material.REDSTONE, Material.BOW,
                Material.REDSTONE, Material.ANVIL, Material.REDSTONE,
                Material.BOW, Material.REDSTONE, Material.BOW
        });

        RECIPES.put(ShardType.ZEPHYR_BLADE, new Material[]{
                Material.FEATHER, Material.REDSTONE, Material.FEATHER,
                Material.REDSTONE, Material.ANVIL, Material.REDSTONE,
                Material.FEATHER, Material.REDSTONE, Material.FEATHER
        });

        RECIPES.put(ShardType.EARTHSPLITTER_HAMMER, new Material[]{
                Material.ANVIL, Material.PRISMARINE_SHARD, Material.ANVIL,
                Material.PRISMARINE_SHARD, Material.ANVIL, Material.PRISMARINE_SHARD,
                Material.ANVIL, Material.PRISMARINE_SHARD, Material.ANVIL
        });

        RECIPES.put(ShardType.CELESTIAL_SPEAR, new Material[]{
                Material.PRISMARINE_SHARD, Material.REDSTONE, Material.PRISMARINE_SHARD,
                Material.REDSTONE, Material.ANVIL, Material.REDSTONE,
                Material.PRISMARINE_SHARD, Material.REDSTONE, Material.PRISMARINE_SHARD
        });
    }


    public static void open(Player p){
        BrokeSMPV1 plugin = BrokeSMPV1.get();
        ShardType equipped = null;
        try {
            equipped = plugin.shards().getEquipped(p);
        } catch (Throwable ignored) {}

        if (equipped != null) {
            openRecipeFor(p, equipped);
        } else {
            // no shard equipped: show selector of shards (icons only)
            openSelector(p);
        }
    }

    private static void openSelector(Player p){
        ShardType[] list = ShardType.values();
        int size = ((list.length-1)/9 + 1)*9;
        Inventory inv = Bukkit.createInventory(null, size, "§6Shard Recipes - Select (Equip a shard to view its recipe)");
        for (int i=0;i<list.length;i++){
            ItemStack icon = list[i].getRecipeIcon();
            inv.setItem(i, icon);
        }
        p.openInventory(inv);
    }

    private static void openRecipeFor(Player p, ShardType type){
        Inventory inv = Bukkit.createInventory(null, 27, "§6Recipe: " + stripColor(type.name()));
        // fill background
        for (int i=0;i<27;i++) inv.setItem(i, BG_PANE);

        // put grid
        Material[] ingr = RECIPES.get(type);
        if (ingr == null) {
            // No recipe defined: show message item in center
            ItemStack no = makeItem(Material.BARRIER, "§cNo recipe defined", Arrays.asList("This shard is bought from Shop NPC."));
            inv.setItem(13, no);
            p.openInventory(inv);
            return;
        }

        for (int i=0;i<9;i++){
            int slot = GRID_SLOTS[i];
            Material m = ingr[i] == null ? Material.AIR : ingr[i];
            ItemStack it;
            if (m == Material.AIR) {
                it = makeGlassPane(" ");
            } else {
                it = new ItemStack(m);
                ItemMeta meta = it.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName("§7Ingredient");
                    it.setItemMeta(meta);
                }
            }
            inv.setItem(slot, it);
        }

        // result
        ItemStack result = type.getRecipeIcon();
        inv.setItem(RESULT_SLOT, result);

        p.openInventory(inv);
    }

    // helpers
    private static ItemStack makeGlassPane(String name){
        ItemStack it = new ItemStack(Material.WHITE_STAINED_GLASS_PANE);
        ItemMeta m = it.getItemMeta();
        if (m != null) {
            m.setDisplayName(name);
            it.setItemMeta(m);
        }
        return it;
    }

    private static ItemStack makeItem(Material mat, String name, List<String> lore){
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        if (m != null){
            m.setDisplayName(name);
            m.setLore(lore);
            it.setItemMeta(m);
        }
        return it;
    }

    private static String stripColor(String s){
        return s.replaceAll("§[0-9a-fk-or]", "");
    }
}
