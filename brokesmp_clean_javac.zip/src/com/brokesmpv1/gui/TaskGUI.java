package com.brokesmpv1.gui;

import com.brokesmpv1.tasks.Task;
import com.brokesmpv1.tasks.TaskManager;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.List;

public class TaskGUI implements Listener {
    private static final String TITLE = "§aBank Tasks";

    public static void open(Player p, TaskManager manager){
        List<Task> tasks = manager.getTasks(p.getUniqueId());
        int size = ((tasks.size()-1)/9 + 1)*9;
        size = Math.max(size, 9);
        Inventory inv = Bukkit.createInventory(null, size, TITLE);
        for (int i=0;i<tasks.size();i++){
            Task t = tasks.get(i);
            ItemStack it = new ItemStack(t.completed() ? Material.LIME_CONCRETE : Material.PAPER);
            ItemMeta m = it.getItemMeta();
            m.setDisplayName("§e" + t.title());
            java.util.List<String> lore = new java.util.ArrayList<>();
            lore.add("§7Goal: §f" + t.goalDesc());
            lore.add("§7Reward: §e" + t.reward() + " coins");
            lore.add(t.completed() ? "§a§lCOMPLETED" : "§c§lINCOMPLETE");
            lore.add("§8Click to claim when completed.");
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(i, it);
        }
        p.openInventory(inv);
        Bukkit.getPluginManager().registerEvents(new Listener(){
            @EventHandler
            public void onClick(InventoryClickEvent e){
                if (!TITLE.equals(e.getView().getTitle())) return;
                e.setCancelled(true);
                if (!(e.getWhoClicked() instanceof Player pl)) return;
                int slot = e.getRawSlot();
                if (slot < 0) return;
                List<Task> tl = manager.getTasks(pl.getUniqueId());
                if (slot >= tl.size()) return;
                Task t = tl.get(slot);
                if (t.completed() && !t.claimed()){
                    manager.claim(pl.getUniqueId(), t);
                    pl.closeInventory();
                    pl.sendMessage("§aClaimed §e" + t.reward() + " coins §afor §f" + t.title());
                } else if (!t.completed()){
                    pl.sendMessage("§cNot completed yet.");
                } else {
                    pl.sendMessage("§7Already claimed.");
                }
            }
        }, Bukkit.getPluginManager().getPlugin("BrokeSMPV1"));
    }
}
