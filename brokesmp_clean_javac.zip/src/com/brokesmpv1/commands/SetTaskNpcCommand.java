package com.brokesmpv1.commands;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.Location;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SetTaskNpcCommand implements CommandExecutor {
    private final BrokeSMPV1 plugin;
    public SetTaskNpcCommand(BrokeSMPV1 plugin){ this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)){ sender.sendMessage("Players only."); return true; }
        if (!p.hasPermission("brokesmp.admin")){ p.sendMessage("§cNo permission."); return true; }
        Location loc = p.getLocation();
        plugin.npcs().spawnTaskNpc(loc);
        p.sendMessage("§aSpawned §lBank Task NPC §aat your location.");
        return true;
    }
}
