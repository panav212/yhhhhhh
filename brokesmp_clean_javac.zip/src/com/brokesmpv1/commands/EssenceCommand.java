package com.brokesmpv1.commands;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class EssenceCommand implements CommandExecutor {
    private final BrokeSMPV1 plugin;
    public EssenceCommand(BrokeSMPV1 plugin){ this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("brokesmp.admin")){ sender.sendMessage("§cNo permission."); return true; }
        if (args.length != 3 || !args[0].equalsIgnoreCase("give")){
            sender.sendMessage("§e/essence give <player> <amount>");
            return true;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null){ sender.sendMessage("§cPlayer not found."); return true; }
        int amt;
        try { amt = Integer.parseInt(args[2]); } catch (Exception ex){ sender.sendMessage("§cInvalid amount."); return true; }
        plugin.economy().addEssence(t, amt);
        sender.sendMessage("§aGave §d" + amt + " essence §ato §e" + t.getName());
        return true;
    }
}
