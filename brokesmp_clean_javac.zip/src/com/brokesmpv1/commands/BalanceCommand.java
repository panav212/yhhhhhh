package com.brokesmpv1.commands;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class BalanceCommand implements CommandExecutor {
    private final BrokeSMPV1 plugin;
    public BalanceCommand(BrokeSMPV1 plugin){ this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)){ sender.sendMessage("Players only."); return true; }
        int bal = plugin.economy().getCoins(p);
        p.sendMessage("§aCoins: §e" + bal + " §7| Essence: §d" + plugin.economy().getEssence(p));
        return true;
    }
}
