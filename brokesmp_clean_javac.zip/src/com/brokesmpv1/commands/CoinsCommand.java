package com.brokesmpv1.commands;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class CoinsCommand implements CommandExecutor {
    private final BrokeSMPV1 plugin;
    public CoinsCommand(BrokeSMPV1 plugin){ this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("brokesmp.admin")){ sender.sendMessage("§cNo permission."); return true; }
        if (args.length != 4){ sender.sendMessage("§e/coins <give|take|set> <player> <amount>"); return true; }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null){ sender.sendMessage("§cPlayer not found."); return true; }
        int amt;
        try { amt = Integer.parseInt(args[2]); } catch (Exception ex){ sender.sendMessage("§cInvalid amount."); return true; }

        switch (args[0].toLowerCase()){
            case "give" -> plugin.economy().addCoins(t, amt);
            case "take" -> plugin.economy().takeCoins(t, amt);
            case "set"  -> plugin.economy().setCoins(t, amt);
            default -> { sender.sendMessage("§e/coins <give|take|set> <player> <amount>"); return true; }
        }
        sender.sendMessage("§aUpdated coins for §e" + t.getName());
        return true;
    }
}
