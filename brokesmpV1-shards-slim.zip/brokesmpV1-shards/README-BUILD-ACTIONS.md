# BrokeSMPV1 — GitHub Actions Build (Maven)

This repo is prepped to build your Paper plugin automatically using **Maven**.

## How to use (from iPhone too!)

1. Create a new GitHub repo on your account.
2. Upload **the entire contents** of this folder to that repo (including `.github/workflows/`).
3. Go to the **Actions** tab in your repo and run **"Build BrokeSMPV1 (Maven)"** (or just push a commit; it runs automatically).
4. When it finishes, open the workflow run → **Artifacts** → download **BrokeSMPV1** → you'll get the compiled `BrokeSMPV1-1.0.0.jar`.
5. Drop that JAR into your server's `plugins/` folder.

### Notes
- JDK 21 is used (matches your pom.xml).
- Maven automatically downloads Paper API (and any other dependencies) from PaperMC’s repo.
- The final JAR is created in `target/`.